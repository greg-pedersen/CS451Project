import psycopg2


qtCreatorfile = "mainwindow.ui"

con = psycopg2.connect(
    host = 'localhost',
    database = 'milestone1datab',
    user = "postgres",
    password = "Patriots12!",
)


# cursor
cur = con.cursor()

## First simple execution
cur.execute("SELECT DISTINCT state FROM business ORDER by state;")

print(cur.fetchall())

## Part 2 of first simple execution
cur.execute("SELECT DISTINCT state FROM business ORDER by state;")

print(cur.fetchone())

## Second simple execution
cur.execute("SELECT DISTINCT city FROM business WHERE state = 'NV' ORDER BY city;")

print(cur.fetchall())

## Third simple execution
cur.execute("SELECT name, state, city FROM business WHERE city = 'Mesa' AND state= 'AZ' ORDER BY name;")

print(cur.fetchall())

con.commit()

cur.close()



con.close()